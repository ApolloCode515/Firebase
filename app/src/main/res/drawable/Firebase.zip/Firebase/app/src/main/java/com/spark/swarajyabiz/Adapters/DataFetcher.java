package com.spark.swarajyabiz.Adapters;

public interface DataFetcher {

}
