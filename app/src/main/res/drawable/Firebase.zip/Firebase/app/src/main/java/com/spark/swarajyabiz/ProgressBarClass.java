package com.spark.swarajyabiz;

import android.app.Dialog;
import android.content.Context;
import android.view.ViewGroup;

public class ProgressBarClass {
    private Dialog dialog;

//    public void load(Context context, boolean show) {
//        if (show) {
//            dialog = new Dialog(context);
//            dialog.setContentView(R.layout.progress_dialog);
//            dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//            dialog.show();
//        } else {
//            // Dismiss the dialog if it's not null and showing
//            if (dialog != null && dialog.isShowing()) {
//                dialog.dismiss();
//                dialog = null; // Set dialog to null after dismissing
//            }
//        }
//    }
}
