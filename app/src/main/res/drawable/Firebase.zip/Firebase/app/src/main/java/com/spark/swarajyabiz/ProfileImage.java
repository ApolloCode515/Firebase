package com.spark.swarajyabiz;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileImage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_image);
    }
}