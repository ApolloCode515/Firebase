package com.spark.admin;

public class CustomImageObject {
    private String shopId;
    private String contactNumber;
    private String imageId;
    private String imageUrl;

    public CustomImageObject(String shopId, String contactNumber, String imageId, String imageUrl) {
        this.shopId = shopId;
        this.contactNumber = contactNumber;
        this.imageId = imageId;
        this.imageUrl = imageUrl;
    }


}

